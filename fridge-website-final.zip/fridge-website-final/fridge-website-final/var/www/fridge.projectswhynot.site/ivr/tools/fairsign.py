import requests as req
import json
from urllib.parse import quote
from datetime import datetime


class TrueSignParser:
    @classmethod
    def get_product(cls, dm_code, _type):
        uri = "https://mobile.api.crpt.ru/mobile/check"
        params = {"code": quote(dm_code.replace("\x1D",
                                                f"{chr(29)}")),
                  "codeType": _type}
        req_url = f"{uri}?" + "&".join([f"{k}={v}" for k, v in params.items()])

        try:
            req_res = req.get(req_url).json()
        except:
            return None

        res = {"name": req_res["productName"]}
        try:
            cat_name_key = [key for key in req_res if key.find("Data") + 4 == len(key) and "code" not in key and "catalog" not in key][0]
            res["expiration_date"] = req_res[cat_name_key]["expirationDate"]
            res["expiration_date"] = res["expiration_date"].split("T")[0]
            prod_date = datetime.fromtimestamp(req_res[cat_name_key]["producedDate"] / 1000)
            res["production_date"] = f"{prod_date:%Y-%m-%d}" # f"{prod_date.year}-{prod_date.month}-{prod_date.day}"

        except:
            res["expiration_date"] = "N/A"
            res["production_date"] = "N/A"



        try:
            res["storing"] = cls._parse_attrs(req_res["catalogData"][0]["good_attrs"], 7)
        except:
            pass

        res = cls._to_form_data(res)
        return res

    @classmethod
    def _parse_attrs(cls, attributes, tgt_attr_group_ids=None):
        if type(tgt_attr_group_ids) is not list:
            tgt_attr_group_ids = [tgt_attr_group_ids]

        def cast(v):
            try:
                return int(v)
            except:
                try:
                    return float(v)
                except:
                    return str(v)

        tgt_attrs = [v for v in attributes if v["attr_group_id"] in tgt_attr_group_ids]

        return {v["attr_name"]: {"value": cast(v["attr_value"]),
                                 "units": v["attr_value_type"]}
                for v in tgt_attrs}


    @classmethod
    def _to_form_data(cls, attrs):
        return attrs

