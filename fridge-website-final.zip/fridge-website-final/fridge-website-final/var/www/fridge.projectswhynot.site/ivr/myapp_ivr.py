# -*- coding: utf-8 -*-

import sys
import os
import flask

from flask import Flask
from flask import render_template
from sqlalchemy import create_engine

from flask import request
from flask import redirect
from flask import session

from datetime import datetime, date, time
from datetime import timedelta
import time
import schedule

import ast
from email.utils import formataddr
from flask import flash, url_for



import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.header import Header
from os import sep
from os.path import basename


import random
import string


username = 'vzemskova_out'
passwd = 'products-ivr'
db_name = 'products'

engine = create_engine("mysql+pymysql://" + username + ":" + passwd + "@projectswhynot.site:11459/" + db_name + "?charset=utf8",  pool_size=10, max_overflow=20, echo=True)
  

# app = Flask(__name__)
app = Flask(__name__, template_folder="/var/www/fridge.projectswhynot.site/ivr/templates/", static_folder="/var/www/fridge.projectswhynot.site/ivr/static/")



if __name__ == "__main__":
    app.run()


def everyday_check(): # ежедневная проверка и рассылка уведомлений
    all_users = get_all_users()
    for user in all_users:
        email = user['email']
        user_id = user['user_id']
        user_products = get_all_products(user_id)
        influence = user['influence']
        update_check(user_products, influence)
        receiver_email = str(email)
        subject = 'Ежедневное оповещение'
        body_expired = ''
        body_nearly_expired = ''
        exp_products = []
        nearly_exp_products = []
        for product in user_products:
            if int(product['shelf_life']) == 0:
                exp_products.append(product['product_name'])
            if int(product['shelf_life']) == int(user['days_before_alert']):
                nearly_exp_products.append(product['product_name'])

        if user['alert'] == 1:
            body_expired = send_exp_notification(exp_products)
        if int(user['days_before_alert']) > 0:
            days_before_alert = user['days_before_alert']
            body_nearly_expired = send_nearly_exp_notification(nearly_exp_products, days_before_alert)
        body = body_expired + ' ' + body_nearly_expired
        emailer = Emailer("your-fridge@projectswhynot.site", "fridgeMadePossible914*", 
            "smtp.beget.com", "Ваш Холодильник!", 
            "your-fridge@projectswhynot.site")
        if body != ' ':
            emailer.send([receiver_email], subject, body)

def clear_all_cookies(): # чистка всех cookies
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("DELETE FROM user_cookies")
    trans.commit()
    connection.close()
    return

def delete_restoring_accounts(): # удаление сохранённых данных о пользователях, удавливих аккаунт в этом месяце
    connection = engine.connect()
    connection.execute("DELETE * FROM user_ivr_restore")
    connection.execute("DELETE * FROM product_restore")
    connection.execute("DELETE * FROM expired_products_restore")
    connection.close()
    return

 # выполнение функций с определённой периодичностью
schedule.every().day.at("12:00").do(everyday_check)
schedule.every().day.at("00:00").do(everyday_check)
schedule.every().monday.do(clear_all_cookies)
schedule.every(30).days.do(delete_restoring_accounts)



app.secret_key = b'j_8e9w1mTMpBAZ7q3mO2n/'  # ключ для создания файлов куки на сайте и дальнейшей идентификации пользователей

app.permanent_session_lifetime = timedelta(days=31) # длительность сессии
    
@app.route("/welcome", methods=['GET','POST'])
def sign_in(): # обработка данных на гостевой странице пользователя

    all_users = get_all_users() # все пользователи списком
    
    cookies = session.get('cookies', default='') # смотрим ключ куки, который есть у пользователя
    user_cookies = get_user_id(cookies) # проверяем, есть ли такой в системе
    if cookies != '':
        for i in user_cookies: # смотрим на список куки-файлов в базе данных
            if cookies == i.get('cookies', ''):
                return redirect('/') # перенаправляем на главную страницу пользователя, уже вошедшего в аккаунт
    
    memory = [{}] # если при отправлении формы что-то введено некорректно, после перезагрузки страницы поля будут содержать ранее введённые значения
    memory[0]['login'] = ''
    memory[0]['password'] = ''
    memory[0]['email'] = ''
    memory[0]['gender'] = '---'
    memory[0]['age'] = ''
    memory[0]['num_of_people'] = ''
    memory[0]['income'] = ''
    
    error = [{}] # оповещения об ошибках, всплывают при неправильно введённых данных
    error[0]['login_error'] = ''
    error[0]['password_error'] = ''
    error[0]['email_error'] = ''
    
    if request.method == "POST":
        if request.form.get('person_agreed'): # пользователь принял политику конфиденциальности
            login = request.form['login'] # логин
            memory[0]['login'] = login
            if get_user_login(login) != []:
                error[0]['login_error'] = u'Пользователь с таким логином уже существует' # ошибка, логин есть в бд
            password = request.form['password'] # пароль
            memory[0]['password'] = password
            if len(password) < 8:
                error[0]['password_error'] = u'Пароль должен содержать не менее 8 символов' # ошибка, пароль есть в бд
            email = request.form['email'] # почта
            memory[0]['email'] = email
            if get_user_email(email) != []:
                error[0]['email_error'] = u'Пользователь с такой почтой уже существует' # ошибка, почта есть в бд
            gender = request.form['gender'] # пол
            memory[0]['gender'] = gender
            age = request.form['age'] # возраст
            memory[0]['age'] = age
            if age == '':
                age = 'не указан'
            num_of_people = request.form['num_of_people'] # кол-во людей, которые пользуются одним холодильником
            memory[0]['num_of_people'] = num_of_people
            if num_of_people == '':
                num_of_people = 1
            income = request.form['income'] # сколько тратится на продукты питания
            memory[0]['income'] = income
            if income == '':
                income = 'не указано'
            
            if error[0]['login_error'] == '' and error[0]['password_error'] == '' and error[0]['email_error'] == '': # проверка на наличие ошибок при заполнении данных
            
                if len(all_users) > 0:
                    user_id = int(all_users[-1].get('user_id')) + 1
                else:
                    user_id = 1
                memo = 1 # отображение памятки включено
                memo_day = 0 # памятка ещё не отображалась
                alert = 1 # оповещения включены
                days_before_alert = 0 # кол-во дней до исчечения срока годности, о которых нужно оповещать равно 0
                photo = 'basic.jpg' # фотография по умолчанию
                
                add_user(user_id, password, login, email, gender, age, num_of_people, income, memo, memo_day, alert, days_before_alert, photo) # пользователь добавляется в бд
        
                return redirect('/log_in') # перенаправление на вход в аккаунт

  
    
    return render_template('sign_in.html', 
                                                saved_answers=memory,
                                                error_alert = error,
                          )
    
    
@app.route("/log_in", methods=['GET','POST'])
def log_in(): # обработка данных на странице со входом в аккаунт
  
    all_users = get_all_users()
    cookies = session.get('cookies', default='') # поиск пользователя по куки, попытка авторизации
    user_cookies = get_user_id(cookies)
    if cookies != '':
        for i in user_cookies:
            if cookies == i.get('cookies', ''):
                return redirect('/')
    
    memory = [{}] # ранее введённые данные в полях
    memory[0]['login'] = ''
    memory[0]['password'] = ''
    memory[0]['email'] = ''
    error = [{}] # оповещения об ошибках при вводе
    error[0]['email_error'] = ''
    error[0]['login_error'] = ''
    error[0]['password_error'] = ''
    error[0]['entry_error'] = ''
    error[0]['email_notification'] = '' # оповещение о том, что почта отправилась на указанную электронную почту
    
    
    if request.method == "POST":
        if request.form.get('email'):
            email = request.form['email'] # почта
            memory[0]['email'] = email
            if get_user_email(email) == []:
                error[0]['email_error'] = u'Пользователя с такой почтой не существует' # оповещение о неверной почте
            else:
                elements_set = string.ascii_letters + string.digits
                new_password = ''.join(random.sample(elements_set, 10)) # генерируем новый пароль
                change_password(new_password, int(get_user_email(email)[0]['user_id'])) # меняем пароль пользователя в базе данных
                receiver_email = str(email) # почта получателя
                subject = 'Новый пароль'
                body = 'Ваш логин: ' + str(get_user_email(email)[0]['login']) + '. Ваш новый пароль на сайте: '+str(new_password)
                emailer = Emailer("your-fridge@projectswhynot.site", "fridgeMadePossible914*", 
                  "smtp.beget.com", "Ваш Холодильник!", 
                  "your-fridge@projectswhynot.site")
                emailer.send([receiver_email], subject, body) # отправляем письмо
                
                
                
                error[0]['email_notification'] = u'Письмо с восстановлением пароля успешно отправлено на указанную почту: '+str(email) # оповещение об успешной смене пароля
                memory[0]['email'] = ''
        else:
            login = request.form['login'] # логин
            memory[0]['login'] = login
            if request.form['login'] == '':
                error[0]['login_error'] = u'Введите логин' # если пользователь не ввёл логин
            password = request.form['password'] # пароль
            memory[0]['password'] = password
            if request.form['password'] == '':
                error[0]['password_error'] = u'Введите пароль' # если пользователь не ввёл пароль
            if get_authorised_user(login, password) != []:
                user = get_authorised_user(login, password) # находим пользователя по логину и паролю
            else:
                if error[0]['login_error'] == '' and error[0]['password_error'] == '':
                    error[0]['entry_error'] = u'Пользователя с таким логином и паролем не существует' # если пользователь не найден
            
            if get_authorised_user(login, password) != []:
                user_id = int(user[0]['user_id']) # айди пользователя
                elements_set = string.ascii_letters + string.digits
                cookies = ''.join(random.sample(elements_set, 12)) # создаём новый куки для входа пользователю
                if get_all_cookies() != []:
                    cookies_id = int(get_all_cookies()[-1]['cookies_id']) + 1 # айди будущего куки в бд
                else:
                    cookies_id = 1
                add_user_cookies(cookies_id, user_id, cookies) # добавление связки айди пользователя и куки в бд
                session['cookies'] = cookies # выдаём пользователю новый куки
                return redirect('/') # перенаправляем на главную страницу

    
    return render_template('log_in.html',
                                             saved_answers=memory,
                                             error_alert = error,
                          )
    
    
@app.route("/", methods=['GET','POST'])
def main(): # обработка данных на главной станице
  
    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
        
    product_types = get_product_types() # все типы продукции списком
    all_zones = get_zones_info() # все зоны списком
    user_info = get_user_info(user_id) # информация о вошедшем пользователе
    
    t = str(datetime.now().date()).split('-') # время на даннный момент
    if user_info[0]['memo_day'] != int(t[2]) and user_info[0]['memo'] == 1: # отображение памятки на странице
        memo = 1
        memo_day = int(t[2])
        change_memo_info(user_id, memo, memo_day) # меняем значение у дня, когда в последний раз отображалась памятка
        return redirect('/#show_memo') # памятка отображается
        
 # информация для поиска продукта по критериям: название, тип продукции, место расположения, открыта ли упаковка, производилась ли сортировка
    product_name = ''
    product_type_id = ''
    search_zone_id = ''
    opened = ''
    sort = ''
    
    if request.method == "POST":
        if 'status_button' in request.form: # смена статуса упаковки на "открыто"
            change_status(zone_id, product_id, shelf_life, start_zone)
            return redirect('/')
          
        if 'search' in request.form: # функция поиска продуктов
            if 'product_name' not in request.form: # поиск по названию
                product_name = ''
            else:
                product_name = request.form['product_name']
            product_type_id = request.form['product_type_id'] # айди продукта
            search_zone_id = request.form['zone_id'] # поиск по месту расположения продукта
            opened = request.form['opened'] # поиск по статусу упаковки
            sort = request.form['sort'] # сортировка продуктов
            
        if 'memo' in request.form: # закрытие памятки или указание "больше не показывать"
            t = str(datetime.now().date()).split('-') # дата на данный момент
            if user_info[0]['memo_day'] != int(t[2]):
                memo_day = int(t[2])
            else:
                memo_day = user_info[0]['memo_day']
            if request.form.get('memo'):
                memo = 0
            else:
                memo = 1
            change_memo_info(user_id, memo, memo_day) # изменеие информации об отображении памятки
            
            return redirect('/')
        
    
    influence = int(user_info[0]['influence']) # учитывать ли воздействие определённых отсеков холодильника на пределённые типы продуктов
    all_products = find_product(user_id, product_name, product_type_id, search_zone_id, opened, sort,influence) # поиск продукта по ранее введённым критериям
    update_check(all_products, influence) # проверка на то, испортились ли продукты, изменение вида отображения дат (годен до, просрочено и проч), вычисление срока хранения продуктов
        
    count = 1
    for b in all_products: # нумерация в таблице с продуктами
        b['number'] = count
        count = count + 1


    for i in range(len(all_products)): # отображение данных о продуктах
        all_products[i]['start_zone'] = 0
        
        if len(all_products[i]['product_note']) > 65: # отображение днинной заметки о продукте
            all_products[i]['product_note'] = all_products[i]['product_note'][0:65]+'...'
            
        if len(all_products[i]['product_name']) > 13: # отображение длинного названия продукта
            all_products[i]['product_name'] = all_products[i]['product_name'][0:13]+'...'
      
        if int(all_products[i]['opened']) == 1: # отображение иконки со статусом упаковки
            all_products[i]['opened'] = 'opened.PNG'
            all_products[i]['href'] = '#close_status'
        elif int(all_products[i]['opened']) == 0:
            all_products[i]['opened'] = 'closed.PNG'
            all_products[i]['href'] = '#change_product_status/'+str(all_products[i]['product_id'])
            
        if int(all_products[i]['expired']) == 1: # способ удаления продукта в зависимости от того, просрочен от или нет
            all_products[i]['exp_href'] = '/zones/expired_products' # если просрочен, по пользователя переносят на страницу с удаление просроченной продукции
            all_products[i]['color'] = '255, 126, 94'
        elif int(all_products[i]['expired']) == 0: # если не просрочен, то можно удатить, нажав на кнопку
            all_products[i]['exp_href'] = '#delete_product/'+str(all_products[i]['zone_id'])+'/'+str(all_products[i]['product_id'])
            
        if float(all_products[i]['shelf_life']) < float(user_info[0]['days_before_alert']): # если пользователь хочет, чтобы его заранее оповещали п продуктов с маленьким остаточным сроком хранения, то подходящие под требования продукты подсвечиваются жёлтым в холодильнике
            if int(all_products[i]['shelf_life']) != 0:
                all_products[i]['color'] = '199, 209, 63'
            
        if float(get_zone_inf(int(all_products[i]['zone_id']), all_products[i]['product_type_id'])) < float(str(max(get_all_inf(all_products[i]['product_type_id'])))): # если у продукта выбран не оптимальный отсек хранения
            all_products[i]['zone_color'] = '217, 139, 24'
        else:
            all_products[i]['zone_color'] = '67, 86, 105'
            
        if int(all_products[i]['zone_id']) == 1: # отображение названий зон, в которых находятся продукты
            all_products[i]['zone'] = u'Основной отсек'
        elif int(all_products[i]['zone_id']) == 2:
            all_products[i]['zone'] = u'Дверца'
        elif int(all_products[i]['zone_id']) == 3:
            all_products[i]['zone'] = u'Морозилка'


    return render_template('main_page.html', 
                                                data=all_zones,
                                                products=all_products,
                                                user=user_info,
                                                p_types = product_types,
                          )


@app.route("/zones/<int:zone_id>", methods=['GET','POST'])
def zone(zone_id): # обработка данных с страниц с отсеками холодильника
  
    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    user_info = get_user_info(user_id)
    
    
    all_products = get_all_products(user_id) # все продукты пользователя
    product_types = get_product_types() # все типы продукции списком
    def get_p_t(product_types): # отображение списка типов продукции при заполнении данных о новом продукте, список переворачивается
        return product_types['product_type_id']
    product_types.sort(key=get_p_t, reverse=True)
    zone_info = get_zone_info(zone_id) # информация о всех зонах холодильника
    date = [{}]
    date[0]['date_now'] = str(datetime.now().date()) # дата на данный момент


    zone_belongings = get_zone_belongings(user_id, zone_id) # все продукты пользователя, которые находятся в данном отсеке
    zone_products = []
    count = 1
    influence = int(user_info[0]['influence']) # учитывать ли воздействие места хранения а срок годности типов продукции
    update_check(zone_belongings, influence) # проверка на истечение срока годности продуктов, красивое отображение дат и вычисление срока хранения
    
    for b in zone_belongings: # отображение данных продукта, так же как и на главной странице
        product_id = b['product_id']
        try:
            product = get_product_info(product_id)
        except:
            raise Exception(f"{product_id}")
        product['number'] = count
        product['start_zone'] = int(product['zone_id'])
        
        if len(product['product_note']) > 65:
            product['product_note'] = product['product_note'][0:65]+'...'

        if len(product['product_name']) > 10:
            product['product_name'] = product['product_name'][0:10]+'...'
            
        if int(product['expired']) == 1:
            product['exp_href'] = '/zones/expired_products'
            product['color'] = '255, 126, 94'
        elif int(product['expired']) == 0:
            product['exp_href'] = '#delete_product/'+str(product['zone_id'])+'/'+str(product['product_id'])
           
        
        if float(b['shelf_life']) < float(user_info[0]['days_before_alert']):
            if int(b['shelf_life']) != 0:
                product['color'] = '199, 209, 63'
          
        zone_products.append(product)
        count = count + 1
        
    influence = int(user_info[0]['influence'])
    update_check(zone_products, influence)
    
    
  
    if request.method == "POST":
        if 'delete_button' in request.form: # удаление продукта
            delete_product(zone_id, product_id)
        if 'status_button' in request.form: # изменение статуса упаковки продукта
            start_zone = zone_id
            change_status(zone_id, product_id, shelf_life, start_zone)
            return redirect('/zones/'+str(zone_id))
        if 'product_name' in request.form: # добавление новой единицы продукта
            if len(request.form['product_name']) > 0: # присваивание айди
                base_products = get_base_products()
                if len(base_products) > 0:
                    p_id = base_products[-1].get('product_id') + 1
                else:
                    p_id = 1
           
                expired = 0 # продукт не просрочен
                opened = 0 # продукт не вскрыт
                added_date = datetime.now() # когда был добавлени в холодильник
                
                if request.form['shelf_life'] == '': # нахождение срока хранения продукта, котроый будет внесён в бд как первоначальный
                    a = request.form['production_date'].split('-') # когда продукт был произведён, список значений (год, месяц, день)
                    b = request.form['expiration_date'].split('-') # значение "годен до", список значаений (год, месяц, день)
                    t = str(datetime.now().date()).split('-') # дата на данный момент
                    
                    months = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 0: 31} # смисок значений число месяца - кол-во дней в нём
                    if int(b[1]) == int(a[1]) and int(b[0]) == int(a[0]): # если месяц и год у "произведено" и "годен до" совпадают
                        shelf_life = (int(b[2]) - int(a[2])) # разница дней в месяце
                    elif (int(a[1]) + 1) % 12 == (int(b[1])) % 12: # если у "произведено" и "годен до" разница в месяц
                        if int(a[1]) == 12: # декабрь имеет значение в словаре не 12, а 0 (остаток при делении на 12)
                            a[1] = 0
                        else:
                            a[1] = int(a[1])
                        shelf_life = months[a[1]] - int(a[2]) + int(b[2]) # срок хранения как сумма дней, которые остались в месяце "произведено" и дней, которые прошли в месяце "годен до"
                        if int(a[1]) == 2 and int(t[0]) % 4 == 0: # если год високосный
                            shelf_life = 29 - int(a[2]) + int(b[2])
                    else:
                        if int(a[1]) == 12: # если декабрь
                            a[1] = 0
                        else:
                            a[1] = int(a[1])
                        shelf_life = int(months[a[1]]) - int(a[2]) + int(b[2]) # часть срока хранения как сумма дней, которые остались в месяце "произведено" и дней, которые прошли в месяце "годен до"
                        
                        if int(b[1]) - int(a[1]) < 0: # разница в месяцах между "произведено" и "годен до"
                            m_diff = 12 + int(b[1]) - int(a[1])
                        else:
                            m_diff = int(b[1]) - int(a[1])
                        year = int(a[0])
                        y = int(b[0]) - int(a[0])
                        if y == 1:
                            y = 0
                        for i in range(1, y * 12 + m_diff): # прибавляем к части срока хранения вторую часть из дней в месяцах между датами
                            if (int(a[1]) + i) % 12 == 2 and year % 4 == 0:
                                shelf_life = shelf_life + 29
                            else:
                                shelf_life = shelf_life + months[(int(a[1]) + i) % 12]
                            if (int(a[1]) + i + 1) % 12 == 1:
                                year = year + 1 # год сменяется

                else:
                    shelf_life = request.form['shelf_life'] # пользователь ввёл свой срок хранения
                zone_id = request.form['zone_id[]'] # отсек холодильника, где будет храниться продукт
                if request.form['product_type_id[]'] == '': # тип родукции продукта
                    product_type_id = 0
                else:
                    product_type_id = request.form['product_type_id[]']
              
                if request.form['opened_life'] == '': # срок хранения после вскрытия продукта
                    opened_life = shelf_life
                else:
                    opened_life = request.form['opened_life']
                    
                # добавление нового продукта
                add_product(p_id, user_id, product_type_id, request.form['zone_id[]'],  request.form['product_name'], request.form['product_amount'], request.form['production_date'], added_date, shelf_life, opened_life, request.form['expiration_date'], request.form['product_note'], opened, expired)


        return redirect('/zones/'+str(zone_id))



    for i in range(len(zone_products)): # отображение статуса упаковки
        if int(zone_products[i]['opened']) == 1:
            zone_products[i]['href'] = 'close_status'
            zone_products[i]['opened'] = 'opened.PNG'
            
        elif int(zone_products[i]['opened']) == 0:
            zone_products[i]['href'] = 'change_product_status/'+str(zone_products[i]['product_id'])
            zone_products[i]['opened'] = 'closed.PNG'
            
            
        if int(zone_products[i]['zone_id']) == 1: # отображение места хранения
            zone_products[i]['zone'] = u'Основной отсек'
        elif int(zone_products[i]['zone_id']) == 2:
            zone_products[i]['zone'] = u'Дверца'
        elif int(zone_products[i]['zone_id']) == 3:
            zone_products[i]['zone'] = u'Морозилка'
    
    
        
    return render_template('fridge.html', 
                                          zone=zone_info, 
                                          products=zone_products,
                                          user=user_info,
                                          p_types = product_types,
                                          date = date,
                                        
                                        
                              )
    
# ----------------------------------------------------------------------------
    
@app.route("/zones/expired_products", methods=['GET','POST'])
def expired_products():

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    all_products = get_all_products(user_id)

    user_info = get_user_info(user_id)
    product_types = get_product_types()
        
      
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)
        
      
    expired_products = [] # составляем список просроченных продуктов пользователя
    count = 1
    for product in all_products:
        if product['expired'] == 1:
            product['number'] = count # нумерация в таблице
            if len(product['product_note']) > 15: # отображение длинной заметки о продукте
                product['product_note'] = product['product_note'][0:15]+'...'
            if len(product['product_name']) > 10: # отображение длинного имени
                product['product_name'] = product['product_name'][0:10]+'...'
            expired_products.append(product)
            count = count + 1
    
  
    if request.method == "POST":
        if 'delete_button' in request.form:  # пользователь нажал на кнопку "удалить"
            for i in range(len(expired_products)):
                expired_product_id = expired_products[i]['product_id'] # айди просроченного продукта
                product_type_id = expired_products[i]['product_type_id'] # тип продукции у продукта
                # список причин, которые указал пользователь
                reason1 = 0
                reason2 = 0
                reason3 = 0
                reason4 = 0
                reason5 = 0
                personal_reason = ''
                if request.form.get('reason1-' + str(expired_product_id)):
                    reason1 = 1 
                if request.form.get('reason2-' + str(expired_product_id)):
                    reason2 = 1
                if request.form.get('reason3-' + str(expired_product_id)):
                    reason3 = 1
                if request.form.get('reason4-' + str(expired_product_id)):
                    reason4 = 1
                if request.form.get('reason5-' + str(expired_product_id)):
                    reason5 = 1
                if request.form.get('personal_reason-' + str(expired_product_id)):
                    personal_reason = request.form['personal_reason-' + str(expired_product_id)]
                if reason1 != 0 or reason2 != 0 or reason3 != 0 or reason4 != 0 or reason5 != 0 or personal_reason != '': # проверка на заполнение хотя бы одной причины
                    # удаление просроченных продуктов, у которых были отмечены причины
                    delete_spoiled_product(expired_product_id, user_id, product_type_id, reason1, reason2, reason3, reason4, reason5, personal_reason)
            return redirect('/zones/expired_products')
          
    for i in range(len(expired_products)):

        if int(expired_products[i]['zone_id']) == 1:
            expired_products[i]['zone'] = u'Основной отсек'
        elif int(expired_products[i]['zone_id']) == 2:
            expired_products[i]['zone'] = u'Дверца'
        elif int(expired_products[i]['zone_id']) == 3:
            expired_products[i]['zone'] = u'Морозилка'

        
    return render_template('expired_products.html', 
                                          products=expired_products,
                                          user=user_info,
                                        
                              )
# -------------------------------------------------------------------------------------
    
  
# путь к файлам в папках проета
basedir = os.path.abspath(os.path.dirname(__file__))
  
UPLOAD_FOLDER = 'static'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'} # допустимые разрешения файлов
  
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

  
@app.route("/user_profile/<int:user_id>", methods=['GET','POST'])
def user_profile(user_id): # обработка данных на странице профиля
                
    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    cookies = session.get('cookies', default='')
    user_info = get_user_info(user_id)

    all_products = get_all_products(user_id)      
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)

    
    if request.method == "POST":
        if 'change_photo' in request.files: # пользователь отправляет запрос на изменение фото с прикреплённых файлом
          
            new_photo = request.files['change_photo'] # прикреплённый файл
            if new_photo.filename == '': # если ничего не прикреплено
                return redirect('/user_profile/' + str(user_id))
            else:
                if user_info[0]['photo'] == 'basic.jpg': # если это первая смена фото
                    photo_id = 1
                else:
                    # закрепление за фотографией нового имени в файлах
                    photo_id = int(str(user_info[0]['photo']).split('_')[1]) + 1
                photo_name = str(user_id)+'_'+str(photo_id)+'_photo.jpg'
                old_photo_name = str(user_id)+'_'+str(photo_id - 1)+'_photo.jpg'
                new_photo.filename = photo_name
                if user_info[0]['photo'] != 'basic.jpg':
                    os.remove(os.path.join(basedir, app.config['UPLOAD_FOLDER'], old_photo_name)) # удаляем старое фото, если оно было
                new_photo.save(os.path.join(basedir, app.config['UPLOAD_FOLDER'], new_photo.filename)) # добавляем новое фото
                change_photo(user_id, photo_name) # меняем название фото профиля у пользователя в бд
                return redirect('/user_profile/' + str(user_id))
            
            
        if 'log_out_button' in request.form: # выход из аккаунта
            delete_user_cookies(user_id, cookies) # удаляем ключ куки из бд
            session.pop('cookies', '') # забираем у пользователя куки
            return redirect('/welcome')
        if 'delete_account_button' in request.form: # удаление аккаунта
            save_restoring_account(user_id) # сохранение данных для возможного восстановления
            delete_account(user_id) # удаление всей информации о пользователе и его продуктах
            return redirect('/welcome')
        
            

    return render_template('user_profile.html', 
                                          user=user_info,
                              )


@app.route("/user_profile/settings", methods=['GET','POST'])
def settings(): # обработка данных на странице с настройками профиля

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    user_info = get_user_info(user_id)

    all_products = get_all_products(user_id)
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)
    
                
    error = [{}] # список ошибок при заполнении полей
    error[0]['login_error'] = ''
    error[0]['email_error'] = ''
    memory = [{}] # сохранение введённых данных
    memory[0]['login'] = user_info[0]['login']
    memory[0]['email'] = str(user_info[0]['email'])
    
    if int(user_info[0]['influence']) == 1: # влияние места хранения на типы продукции
        memory[0]['influence'] = u'учитывается'
    else:
        memory[0]['influence'] = u'не учитывается'
        
    if user_info[0]['gender'] == 'female': # пол
        memory[0]['gender'] = u'женский'
    elif user_info[0]['gender'] == 'male':
        memory[0]['gender'] = u'мужской'
    else:
        memory[0]['gender'] = u'не определено'
        
    if int(user_info[0]['alert']) == 1: # уведомления
        memory[0]['alert'] = u'включены'
    else:
        memory[0]['alert'] = u'выключены'
        
    if int(user_info[0]['memo']) == 1: # отображение памятки
        memory[0]['memo'] = u'отображается'
    else:
        memory[0]['memo'] = u'не отображается'
    
    if request.method == "POST":
        if 'login' in request.form: # изменение информации о пользователе
            if request.form['days_before_alert'] == '': # дни до истечения срока хранеия у продукта, которые учитываются при отображении продуктов в холодильнике
                days_before_alert = 0
            else:
                days_before_alert = request.form['days_before_alert']
            user_with_login = get_user_login(request.form['login']) # новый логин
            if user_with_login != []: # проверка логина на корректность
                if user_with_login[0].get('user_id', 0) != user_id:
                    error[0]['login_error'] = u'Логин уже занят'
                    memory[0]['login'] = request.form['login']
            user_with_email = get_user_email(str(request.form['email'])) # новая почта
            if user_with_email != []:
                if user_with_email[0].get('user_id', 0) != user_id:
                    error[0]['email_error'] = u'Почта уже занята'
                    memory[0]['email'] = str(request.form['email'])
                    

            if error[0]['login_error'] == '' and error[0]['email_error'] == '': # проверка на наличие ошибок при заполнении логина и пароля
                if request.form.get('memo'): # отображение памятки
                    memo = request.form['memo']
                else:
                    memo = int(user_info[0]['memo'])
                if request.form.get('alert'): # присылание оповещений
                    if request.form['alert'] == '0' or request.form['alert'] == '1':
                        alert = request.form['alert']
                else:
                    alert = int(user_info[0]['alert'])
                if request.form.get('gender'): # пол
                    if request.form['gender'] != '':
                        gender = request.form['gender']
                else:
                    gender = user_info[0]['gender']
                if request.form.get('influence'): # учитывать ли воздействия места хранения на типы продукции
                    influence = request.form['influence']
                    if int(influence) == 1 and int(user_info[0]['influence']) != 1:
                        influence = 0
                        # изменение информации о пользователе
                        change_settings(user_id, request.form['login'], request.form['password'], request.form['email'], gender, request.form['age'], request.form['num_of_people'], request.form['income'], influence, alert, days_before_alert, memo)
                        return redirect('/user_profile/settings#save_settings') # если до этого функция была отключена, пользователя предупреждают
                else:
                    influence = int(user_info[0]['influence'])
                # изменение информации о пользователе
                change_settings(user_id, request.form['login'], request.form['password'], request.form['email'], gender, request.form['age'], request.form['num_of_people'], request.form['income'], influence, alert, days_before_alert, memo)
                return redirect('/user_profile/settings#close')
            
        if request.form.get('save_settings_button'): # подтверждение учёта воздействия условий хранения на типы продукции
            change_settings_influence(user_id)
            return redirect('/user_profile/settings')
            
            
    return render_template('settings.html', 
                                          user=user_info,
                                          error_alert=error,
                                          memory=memory,
                              )

    
@app.route("/user_profile/terms_of_usage", methods=['GET','POST'])
def terms_of_usage(): # обработка данных на странице с условиями использования

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    user_info = get_user_info(user_id)

    all_products = get_all_products(user_id)
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)
    
  

    return render_template('terms_of_usage.html', 
                                          user=user_info,
                              )
    
@app.route("/user_profile/reasons", methods=['GET','POST'])
def reasons(): # обработка данных на странице со статьёй

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    user_info = get_user_info(user_id)

    all_products = get_all_products(user_id)
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)
    
  

    return render_template('reasons.html', 
                                          user=user_info,
                              )
    
@app.route("/privacy_policy", methods=['GET','POST'])
def privacy_policy(): # обработка данных на странице с политикой конфиденциальности

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/privacy_policy_guest')
    user_info = get_user_info(user_id)

    all_products = get_all_products(user_id)
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)
    
  

    return render_template('privacy_policy.html', 
                                          user=user_info,
                              )
    
@app.route("/privacy_policy_guest", methods=['GET','POST'])
def privacy_policy_guest(): # обработка данных на странице с политикой конфиденциальности и правилами использования для гостей

    user_id = cookies_check()
    if int(user_id) != 0:
        return redirect('/privacy_policy')

    
    return render_template('privacy_policy_guest.html')


@app.route("/memo", methods=['GET','POST'])
def memo(): # обработка данных на странице с памяткой

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
    user_info = get_user_info(user_id)

    all_products = get_all_products(user_id)
    influence = int(user_info[0]['influence'])
    update_check(all_products, influence)
    
  

    return render_template('memo.html', 
                                          user=user_info,
                              )

    
    
@app.route("/about_product/<int:product_id>", methods=['GET','POST'])
def about_product(product_id): # обработка данных на странице с информацией о продукте

    user_id = cookies_check()
    if int(user_id) == 0:
        return redirect('/welcome')
      
    product_info = get_product_inf(product_id) # информация о продукте
    user_info = get_user_info(user_id) # информация о пользователе
    zone_id = product_info[0].get('zone_id') # айди места расположения продукта
    zone_info = get_zone_info(zone_id) # информация о зоне холодильника
    product_type_id = product_info[0].get('product_type_id') # айди типа продукции
    type_info = get_type(product_type_id) # информация о типе продукции продукта
    
    product_types = get_product_types() # все типы продукции списком
    def get_p_t(product_types):
        return product_types['product_type_id']
    product_types.sort(key=get_p_t, reverse=True) # список типов продукции отображается в перевёрнутом виде при изменении типа продукции
    
    ex_status = product_info[0].get('expired') # просрочен ли продукт
    ex_info = get_ex_info(ex_status)
    op_status = product_info[0].get('opened') # открыта ли упаковка продукта
    op_info = get_op_info(op_status)
    
    influence = int(user_info[0]['influence'])
    update_check(product_info, influence)
    
    if request.method == "POST":
        if 'product_name' in request.form:  # изменение информации о продукте
            if len(request.form['product_name']) > 0:
                
                product_info1 = get_product_info(product_id) # старая информация о продукте
                shelf_life = int(product_info1.get('shelf_life')) # старый срок хранения
                
                product_name = product_info[0].get('product_name') # название продукта
                if request.form['product_name'] != '':
                    product_name = request.form['product_name'] # меняем, если указано
                    
                product_type_id = product_info[0].get('product_type_id') # тип продукции у продукта
                if request.form.get('product_type_id[]') and int(product_type_id) == 0:
                    product_type_id = request.form['product_type_id[]'] # меняем, если указано
                zone_id = product_info[0].get('zone_id') # место хранения
                if request.form.get('zone_id'):
                    zone_id = request.form['zone_id'] # меняем, если указано

                 # меняем информацию о продукте
                change_product_info(product_id, product_type_id, zone_id, product_name, request.form['product_amount'], request.form['product_note'], shelf_life)
        return redirect('/zones/'+str(zone_id))
        
    advice_list = [] # если место хранения неоптимальное, предлагаем пользователю его сменить
    # сравнение коэф. на которые умножается срок хранения определённой продукции (тот, который сейчас у продукта, и тот, который наибольший в бд)
    if float(get_zone_inf(int(zone_id), product_type_id)) < float(str(max(get_all_inf(product_type_id)))):
        adv_list = get_adviced_zones(product_type_id)
        for i in range(len(adv_list)):
            a_dict = {}
            adv_zone_id = adv_list[i]['zone_id']
            adv_zone = str(get_zone_info(adv_zone_id)['zone_id'])
            if int(adv_zone_id) != int(zone_id):
                if int(adv_zone) == 1:
                    zone_name = u'Основном отсеке'
                elif int(adv_zone) == 2:
                    zone_name = u'Дверце'
                elif int(adv_zone) == 3:
                    zone_name = u'Морозилке'
                a_dict['zone_name'] = zone_name
                advice_list.append(a_dict)
    
    
    return render_template('about_product.html', 
                                                product=product_info,
                                                user=user_info,
                                                p_type=type_info,
                                                zone=zone_info,
                                                opened=op_info,
                                                expired=ex_info,
                                                advice=advice_list,
                                                p_types = product_types,
                          )
    
    
    
def dump(x):
    return flask.json.dumps(x)

#-----------------------------------------------------------------------------------------------
# cookies - создание, закрепление и нахождение пользователя
  
def add_user_cookies(cookies_id, user_id, cookies):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("INSERT INTO user_cookies(cookies_id, user_id, cookies) VALUES (%s, %s, %s)", (cookies_id, user_id, cookies))
    trans.commit()
    connection.close()
    return
  
def get_all_cookies():
    connection = engine.connect()
    cookies_table = connection.execute("select * from user_cookies")
    connection.close()
    all_cookies = [dict(row) for row in cookies_table]
    return all_cookies
  
  
def cookies_check():
    cookies = session.get('cookies', default='')
    user_cookies = get_user_id(cookies)
    user_id = 0
    if cookies != '':
        for i in range(len(user_cookies)):
            if cookies == user_cookies[i].get('cookies', ''):
                user_id = int(user_cookies[i]['user_id'])
    return user_id
  
def delete_user_cookies(user_id, cookies):
    connection = engine.connect()
    connection.execute("DELETE FROM user_cookies WHERE user_id=%s and cookies=%s", user_id, cookies)
    connection.close()
    return redirect('/')
  
def get_user_id(cookies):
    connection = engine.connect()
    user_table = connection.execute("select * from user_cookies where cookies=%s", cookies)
    connection.close()
    user = [dict(row) for row in user_table]
    return user
  
  
#-----------------------------------------------------------------------------------------------
# вход и выход из аккаунта, создание и удаление аккаунта
  
def get_authorised_user(login, password):
    connection = engine.connect()
    user_table = connection.execute("select * from user_ivr where login=%s AND password=%s", login, password)
    connection.close()
    user = [dict(row) for row in user_table]
    return user
  
def add_user(user_id, password, login, email, gender, age, num_of_people, income, memo, memo_day, alert, days_before_alert, photo):
	connection = engine.connect()
	trans = connection.begin()

	connection.execute("INSERT INTO user_ivr(user_id, password, login, email, gender, age, num_of_people, income, influence, memo, memo_day, alert, days_before_alert, photo) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 1, %s, %s, %s, %s, %s)", (user_id, password, login, email, gender, age, num_of_people, income, memo, memo_day, alert, days_before_alert, photo))
	
	trans.commit()
	connection.close()
	
	return
  
def change_password(new_password, user_id):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("UPDATE user_ivr SET password=%s WHERE user_id=%s", new_password, user_id)
    trans.commit()
    connection.close()
    return
  
def save_restoring_account(user_id):
    connection = engine.connect()
    trans = connection.begin()
    user_table = connection.execute("select * from user_ivr where user_id=%s", user_id)
    user_table = [dict(row) for row in user_table]
    connection.execute("INSERT INTO user_ivr_restore (user_id, password, login, email, gender, age, num_of_people, income, influence, memo, memo_day, alert, days_before_alert, photo) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (user_table[0]['user_id'], user_table[0]['password'], user_table[0]['login'], user_table[0]['email'], user_table[0]['gender'], user_table[0]['age'], user_table[0]['num_of_people'], user_table[0]['income'], user_table[0]['influence'], user_table[0]['memo'], user_table[0]['memo_day'], user_table[0]['alert'], user_table[0]['days_before_alert'], user_table[0]['photo']))
    
    product_table = connection.execute("select * from product where user_id=%s", user_id)
    product_table = [dict(row) for row in product_table]
    if product_table != []:
        for i in range(len(product_table)):
            connection.execute("INSERT INTO product_restore VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (product_table[i]['product_id'], product_table[i]['user_id'], product_table[i]['product_type_id'], product_table[i]['zone_id'], product_table[i]['product_name'], product_table[i]['product_amount'], product_table[i]['production_date'], product_table[i]['added_date'], product_table[i]['shelf_life'], product_table[i]['expiration_date'], product_table[i]['product_note'], product_table[i]['opened'], product_table[i]['expired'], product_table[i]['expiration_day'], product_table[i]['opened_life']))
   
    expired_table = connection.execute("select * from expired_products where user_id=%s", user_id)
    expired_table = [dict(row) for row in expired_table]
    if expired_table != []:
        for i in range(len(expired_table)):
            connection.execute("INSERT INTO expired_products_restore VALUES (%s, %s, %s, %s, %s, %s, %s)", (expired_table[i]['expired_product_id'], expired_table[i]['user_id'], expired_table[i]['product_type_id'], expired_table[i]['reason1'], expired_table[i]['reason2'], expired_table[i]['reason3'], expired_table[i]['personal_reason']))
    trans.commit()
    connection.close()
    return
  
def delete_account(user_id):
    connection = engine.connect()
    connection.execute("DELETE FROM expired_products WHERE user_id=%s", user_id)
    connection.execute("DELETE FROM product WHERE user_id=%s", user_id)
    connection.execute("DELETE FROM telegram_notification WHERE user_id=%s", user_id)
    connection.execute("DELETE FROM user_ivr WHERE user_id=%s", user_id)
    connection.execute("DELETE FROM user_cookies WHERE user_id=%s", user_id)
    connection.close()
    return redirect('/') 
  
def get_user_login(login):
    connection = engine.connect()
    user_table = connection.execute("select * from user_ivr where login=%s", login)
    connection.close()
    user = [dict(row) for row in user_table]
    return user
  

  
#-----------------------------------------------------------------------------------------------
# отправление оповещений
  
def get_user_email(email):
    connection = engine.connect()
    user_table = connection.execute("select * from user_ivr where email=%s", email)
    connection.close()
    user = [dict(row) for row in user_table]
    return user
  
  
class Emailer:
    def __init__(self, username, passwd, server_name, sender_name, sender_email):
        self.server = smtplib.SMTP(server_name, 25)
        self.server.starttls()
        self.server.login(username, passwd)
        self.sender = [sender_name, sender_email]
        
    def send(self, receivers, subject, body, attachments=None, copy_receivers=None):
        message = MIMEMultipart()
        message["From"] = formataddr((str(Header(self.sender[0], 'utf-8')), 
                                      self.sender[1])) # f"{self.sender[0]} <{self.sender[1]}>" # self.sender[1]
        message["To"] = ",".join(receivers)
        if copy_receivers is not None:
            message["Cc"] = ",".join(copy_receivers)
        message["Subject"] = subject
#         message.add_header('reply-to', sender[1])
        message.attach(MIMEText(body, "html"))
        
        if attachments is not None:
            for fpath in attachments:
                with open(fpath, "rb") as fil:
                    part = MIMEApplication(
                        fil.read(),
                        Name=basename(fpath)
                    )
                part['Content-Disposition'] = 'attachment; filename="%s"' % basename(fpath)
                message.attach(part)
        if copy_receivers is None:
            copy_receivers = []
        self.server.sendmail(self.sender[1], 
                             receivers + copy_receivers,
                             message.as_string())
    
    def close(self):
        self.server.quit()
        
  
#-----------------------------------------------------------------------------------------------
# поиск информации о зонах и о воздействии зон на продукт
  
def get_zone_inf(zone_id, product_type_id): # информация о воздействии определённой зоны на определённую продукцию
    connection = engine.connect()
    zone_inf_table = connection.execute("select * from zone_influence where zone_id=%s AND product_type_id=%s", zone_id, product_type_id)
    connection.close()
    zone_inf = [dict(row) for row in zone_inf_table]
    return zone_inf[0].get('influence')
  
def get_adviced_zones(product_type_id): # рекомендации по хранению
    connection = engine.connect()
    zone_inf_table = connection.execute("select * from zone_influence where product_type_id=%s AND influence>=1", product_type_id)
    connection.close()
    zone_inf = [dict(row) for row in zone_inf_table]
    return zone_inf
  
def get_zone_info(zone_id):
    connection = engine.connect()
    zone_table = connection.execute("select * from zones where zone_id=%s", zone_id)
    connection.close()
    zone = [dict(row) for row in zone_table]
    return zone[0]
  
def get_zones_info(): # информация списком о всех зонах
    connection = engine.connect()
    all_zones_table = connection.execute("select * from zones")
    connection.close()
    zones_info = [dict(row) for row in all_zones_table]
    return zones_info
  
def get_zone_belongings(user_id, zone_id): # информация о всех принадлежностях зона -> продукт
    connection = engine.connect()
    zone_belongings_table = connection.execute("select * from product where zone_id=%s AND user_id=%s", zone_id, user_id) 
    connection.close()
    zone_belongings = [dict(row) for row in zone_belongings_table]
    return zone_belongings

  
#-----------------------------------------------------------------------------------------------
# названия и отображение статусов (открыто, закрыто, просрочено)
  
def get_ex_info(ex_status):
    connection = engine.connect()
    ex_table = connection.execute("select * from expired where status=%s", ex_status)
    connection.close()
    ex_info = [dict(row) for row in ex_table]
    return ex_info[0]
  
def get_op_info(op_status):
    connection = engine.connect()
    op_table = connection.execute("select * from opened where status=%s", op_status)
    connection.close()
    op_info = [dict(row) for row in op_table]
    return op_info[0]
 

#-----------------------------------------------------------------------------------------------
# информация о пользователях и пользователе
  
def get_all_users():
    connection = engine.connect()
    users_table = connection.execute("select * from user_ivr")
    connection.close()
    all_users = [dict(row) for row in users_table]
    return all_users
  
def get_user_info(user_id):
    connection = engine.connect()
    user_table = connection.execute("select * from user_ivr where user_id=%s", user_id)
    connection.close()
    user_info = [dict(row) for row in user_table]
    return user_info
  
  
#-----------------------------------------------------------------------------------------------
# вся информация о продуктах
  
def get_all_products(user_id): # информация о продуктах пользователя списком
    connection = engine.connect() 
    all_products_table = connection.execute("select * from product WHERE user_id=%s", user_id) 
    connection.close()
    all_products = [dict(row) for row in all_products_table]
    return all_products
  
def get_all_inf(product_type_id):
    connection = engine.connect() 
    all_inf_table = connection.execute("select influence from zone_influence WHERE product_type_id=%s", product_type_id) 
    connection.close()
    all_inf0 = [dict(row) for row in all_inf_table]
    all_inf = []
    for i in range(len(all_inf0)):
        all_inf.append(all_inf0[i]['influence'])
    return all_inf
  
def get_base_products(): # информация о всех продуктах списком
    connection = engine.connect() 
    all_products_table = connection.execute("select * from product") 
    connection.close()
    base_products = [dict(row) for row in all_products_table]
    return base_products

def get_type(product_type_id):
    connection = engine.connect() 
    type_table = connection.execute("select * from product_types WHERE product_type_id=%s", product_type_id) 
    connection.close()
    type_info = [dict(row) for row in type_table]
    return type_info[0]
  
def product_spoiled(product_id, expiration_day):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("UPDATE product SET expired=1, shelf_life=0, expiration_day=%s WHERE product_id=%s", expiration_day, product_id)
    trans.commit()
    connection.close()
    return
  

def find_product(user_id, product_name, product_type_id, zone_id, opened, sort, influence):
    connection = engine.connect() 

    if product_name != '':
        product_name = '%' + product_name + '%'
        if product_type_id == '':
            if zone_id == '':
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND user_id=%s", product_name, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND opened=%s AND user_id=%s", product_name, opened, user_id)
  #              if product_name in product.get('product_name')
            else:
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND zone_id=%s AND user_id=%s", product_name, zone_id, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND opened=%s AND zone_id=%s AND opened=%s AND user_id=%s", product_name, zone_id, opened, user_id)
        else: 
            if zone_id == '':
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND product_type_id=%s AND user_id=%s", product_name, product_type_id, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND product_type_id=%s AND opened=%s AND user_id=%s", product_name, product_type_id, opened, user_id)
            else:
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND (product_type_id, zone_id, user_id)=(%s,%s,%s)", product_name, product_type_id, zone_id, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where product_name LIKE %s AND product_type_id=%s AND zone_id=%s AND opened=%s AND user_id=%s", product_name, product_type_id, zone_id, opened, user_id)
                
        found_products = [dict(row) for row in all_found_products_table]


    if product_name == '':
        if product_type_id == '':
            if zone_id == '':
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where user_id=%s", user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where opened=%s AND user_id=%s", opened, user_id)
            else:
                if opened == '':
                     all_found_products_table = connection.execute("select * from product where zone_id=%s AND user_id=%s", zone_id, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where zone_id=%s AND opened=%s AND user_id=%s", zone_id, opened, user_id)
        else:
            if zone_id == '':
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where product_type_id=%s AND user_id=%s", product_type_id, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where product_type_id=%s AND opened=%s AND user_id=%s", product_type_id, opened, user_id)
            else:
                if opened == '':
                    all_found_products_table = connection.execute("select * from product where (product_type_id, zone_id, user_id)=(%s,%s,%s)", product_type_id, zone_id, user_id)
                else:
                    all_found_products_table = connection.execute("select * from product where (product_type_id, zone_id, user_id)=(%s,%s,%s) AND opened=%s", product_type_id, zone_id, user_id, opened)
        found_products = [dict(row) for row in all_found_products_table]
        
        
    if sort != '':
        
        if sort == '0':
            def get_shelf_life(found_products):
                return int(found_products['shelf_life'])
            found_products.sort(key=get_shelf_life)
        if sort == '1':
            def get_shelf_life(found_products):
                return int(found_products['shelf_life'])
            found_products.sort(key=get_shelf_life, reverse=True)
      
    connection.close()
    return found_products
  
  
  
def add_product(p_id, user_id, product_type_id, zone_id, product_name, product_amount, production_date, added_date, shelf_life, opened_life, expiration_date, product_note, opened, expired):
	connection = engine.connect()
	trans = connection.begin()
	connection.execute("INSERT INTO product(product_id, user_id, product_type_id, zone_id, product_name, product_amount, production_date, added_date, shelf_life, expiration_date, product_note, opened, expired, opened_life) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (p_id, user_id, product_type_id, zone_id, product_name, product_amount, production_date, added_date, shelf_life, expiration_date, product_note, opened, expired, opened_life))
	trans.commit()
	connection.close()
	return
  
@app.route("/delete_product/<int:zone_id>/<int:product_id>", methods=["POST"])
def delete_product(zone_id, product_id): # Удалить продукт 
    connection = engine.connect()
    trans = connection.begin()
    expired_table = connection.execute("select * from product where product_id=%s", product_id)
    expired = [dict(row) for row in expired_table]
    expired = expired[0]['expired']
    if expired != 1:
        connection.execute("DELETE FROM product WHERE product_id=%s", product_id)
        trans.commit()
        connection.close()
        return redirect('/zones/'+str(zone_id))
    else:
        trans.commit()
        connection.close()
        return redirect('/zones/expired_products')


def delete_spoiled_product(expired_product_id, user_id, product_type_id, reason1, reason2, reason3, reason4, reason5, personal_reason):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("INSERT INTO expired_products(expired_product_id, user_id, product_type_id, reason1, reason2, reason3, reason4, reason5, personal_reason) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)", (expired_product_id, user_id, product_type_id, reason1, reason2, reason3, reason4, reason5, personal_reason))
    connection.execute("DELETE FROM product WHERE product_id=%s", expired_product_id)
    trans.commit()
    connection.close()
    return
  
@app.route("/change_product_status/<int:zone_id>/<int:product_id>/<int:shelf_life>/<int:start_zone>", methods=["POST"])
def change_status(zone_id, product_id, shelf_life, start_zone):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("UPDATE product SET opened=1 WHERE product_id=%s", product_id)
    product_table = connection.execute("select * from product where product_id=%s", product_id)  
    product = [dict(row) for row in product_table]
    user_id = product[0]['user_id']
    user_table = connection.execute("select * from user_ivr where user_id=%s", user_id)
    user = [dict(row) for row in user_table]
    influence = int(user[0]['influence'])
    for product in product:
        t = str(datetime.now().date()).split('-')
        months = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 0: 31}
        
        p_shelf_life = float(product['shelf_life'])
        p_pd = str(product['production_date']).split('-')
        production_date = str(product['production_date']).split("-")
        if int(production_date[1]) == 0:
            m = 12
        else:
            m = int(production_date[1])
        #p_d1 = [production_date[2], months_names[m], production_date[0]]
        #product['production_date'] = ' '.join(p_d1)
        a_d = str(product['added_date']).split(' ')
        if int(str(a_d[0]).split('-')[1]) == 0:
            m = 12
        else:
            m = int(str(a_d[0]).split('-')[1])
        #a_d1 = [str(a_d[1]).split(':')[0], str(a_d[1]).split(':')[1]]
        #a_d2 = [str(int(str(a_d[0]).split('-')[2])), months_names[m], str(a_d[0]).split('-')[0]]
        #product['added_date'] = ' '.join(a_d2) + ' ' + ':'.join(a_d1)
        
        if int(t[1]) == int(p_pd[1]) and int(t[0]) == int(p_pd[0]):
            a = int(t[2]) - int(p_pd[2])
        elif (int(p_pd[1]) + 1) % 12 == (int(t[1])) % 12:
            if int(p_pd[1]) == 2 and int(t[0]) % 4 == 0:
                months[2] = 29
            a = months[int(p_pd[1])] - int(p_pd[2]) + int(t[2])
        else:
            a = months[int(p_pd[1])] - int(p_pd[2]) + int(t[2])
            if int(t[1]) - int(p_pd[1]) < 0:
                m_diff = 12 + int(t[1]) - int(p_pd[1])
            else:
                m_diff = int(t[1]) - int(p_pd[1])
            year = int(p_pd[0])
            for i in range(1, (int(t[0]) - int(p_pd[0])) * 12 + m_diff):
                if (int(p_pd[1]) + i) % 12 == 2 and year % 4 == 0:
                    a = a + 29
                else:
                    a = a + months[(int(p_pd[1]) + i) % 12]
                if (int(p_pd[1]) + i + 1) % 12 == 1:
                    year = year + 1
        shelf_life_dif = float(product['shelf_life']) - float(a)
        if int(influence) == 1:
            zone_inf = get_zone_inf(int(product['zone_id']), int(product['product_type_id']))
            shelf_life_dif = shelf_life_dif * float(zone_inf)
            
        opened_life = product.get('opened_life')
        opened_life = float(opened_life) + float(a)
        #shelf_life_saved = product[0].get('shelf_life')
        if float(opened_life) <= float(shelf_life_dif):
            connection.execute("UPDATE product SET shelf_life=%s WHERE product_id=%s", opened_life, product_id)
    
   # new_shelf_life = int(float(shelf_life_saved) - float(shelf_life) + float(opened_life))
    #if int(opened_life) < int(shelf_life) and opened_life != 0.33333:
     #   connection.execute("UPDATE product SET shelf_life=%s WHERE product_id=%s", new_shelf_life, product_id)
    trans.commit()
    connection.close()
    if start_zone == 0:
        return redirect('/')
    else:
        return redirect('/zones/'+str(zone_id))
    


def change_product_info(product_id, product_type_id, zone_id, product_name, product_amount, product_note, shelf_life):
    connection = engine.connect()
    trans = connection.begin()
    p_id = product_id
    connection.execute("UPDATE product SET product_type_id=%s, zone_id=%s, product_name=%s, product_amount=%s, product_note=%s, shelf_life=%s WHERE product_id=%s", (product_type_id, zone_id, product_name, product_amount, product_note, shelf_life, product_id))
    zone_id = connection.execute("select zone_id from product WHERE product_id=%s", product_id)
    trans.commit()
    connection.close()
    return redirect('/zones/'+str(zone_id))
  
  
def get_product_info(product_id): # информация об одном продукте
    connection = engine.connect()
    product_table = connection.execute("select * from product where product_id=%s", product_id)
    connection.close()
    this_product = [dict(row) for row in product_table]
    return this_product[0]
  
def get_product_inf(product_id): # информация об одном продукте
    connection = engine.connect()
    product_table = connection.execute("select * from product where product_id=%s", product_id)
    connection.close()
    product_info = [dict(row) for row in product_table]
    return product_info
  
  
def get_product_types(): # информация о типах продуктов
    connection = engine.connect()
    product_type_table = connection.execute("select * from product_types")
    connection.close()
    product_types = [dict(row) for row in product_type_table]
    return product_types
  

#-----------------------------------------------------------------------------------------------
# профиль пользователя

def change_photo(user_id, new_photo):
    connection = engine.connect()
    trans = connection.begin()

    connection.execute("UPDATE user_ivr SET photo=%s WHERE user_id=%s", (new_photo, user_id))
    
    trans.commit()
    connection.close()
    return
  
def change_memo_info(user_id, memo, memo_day):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("UPDATE user_ivr SET memo=%s, memo_day=%s WHERE user_id=%s", memo, memo_day, user_id)
    trans.commit()
    connection.close()
    return redirect('/#close')
  
  
def change_settings_influence(user_id):
    connection = engine.connect()
    trans = connection.begin()
    connection.execute("UPDATE user_ivr SET influence=1 WHERE user_id=%s", user_id)
    
    trans.commit()
    connection.close()
    return
  
def change_settings(user_id, login, password, email, gender, age, num_of_people, income, influence, alert, days_before_alert, memo):
    connection = engine.connect()
    trans = connection.begin()

    connection.execute("UPDATE user_ivr SET login=%s, password=%s, email=%s, gender=%s, age=%s, num_of_people=%s, income=%s, influence=%s, alert=%s, days_before_alert=%s, memo=%s WHERE user_id=%s", (login, password, email, gender, age, num_of_people, income, influence, alert, days_before_alert, memo, user_id))
    
    trans.commit()
    connection.close()
    return
  
 
#----------------------------------------------------------------------------------------
# проверка просрока


def update_check(all_products, influence):
    t = str(datetime.now().date()).split('-')
    months = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 0: 31}
    months_names = {1: u'янв.', 2: u'февр.', 3: u'март', 4: u'апр.', 5: u'май', 6: u'июнь', 7: u'июль', 8: u'авг.', 9: u'сент.', 10: u'окт.', 11: u'нояб.', 0: u'дек.'}
    for product in all_products:
        p_shelf_life = float(product['shelf_life'])
        p_pd = str(product['production_date']).split('-')
        production_date = str(product['production_date']).split("-")
        if int(production_date[1]) == 12:
            m = 0
        else:
            m = int(production_date[1])
        p_d1 = [production_date[2], months_names[m], production_date[0]]
        product['production_date'] = ' '.join(p_d1)
        a_d = str(product['added_date']).split(' ')
        if int(str(a_d[0]).split('-')[1]) == 12:
            m = 0
        else:
            m = int(str(a_d[0]).split('-')[1])
        a_d1 = [str(a_d[1]).split(':')[0], str(a_d[1]).split(':')[1]]
        a_d2 = [str(int(str(a_d[0]).split('-')[2])), months_names[m], str(a_d[0]).split('-')[0]]
        product['added_date'] = ' '.join(a_d2) + ' ' + ':'.join(a_d1)
        
        if int(t[1]) == int(p_pd[1]) and int(t[0]) == int(p_pd[0]):
            a = int(t[2]) - int(p_pd[2])
        elif (int(p_pd[1]) + 1) % 12 == (int(t[1])) % 12:
            a = months[int(p_pd[1])] - int(p_pd[2]) + int(t[2])
            if int(p_pd[1]) == 2 and int(t[0]) % 4 == 0:
                a = 29 - int(p_pd[2]) + int(t[2])
        else:
            a = months[int(p_pd[1])] - int(p_pd[2]) + int(t[2])
            if int(t[1]) - int(p_pd[1]) < 0:
                m_diff = 12 - int(p_pd[1]) + int(t[1])
            else:
                m_diff = int(t[1]) - int(p_pd[1])
            year = int(p_pd[0])
            
            y = int(t[0]) - int(p_pd[0])
            if y == 1:
                 y = 0
            for i in range(1, y * 12 + m_diff):
                if (int(p_pd[1]) + i) % 12 == 2 and year % 4 == 0:
                    a = a + 29
                else:
                    a = a + months[(int(p_pd[1]) + i) % 12]
                if (int(p_pd[1]) + i + 1) % 12 == 1:
                    year = year + 1
        
        shelf_life_dif = float(product['shelf_life']) - float(a)
        if int(influence) == 1:
            zone_inf = get_zone_inf(int(product['zone_id']), int(product['product_type_id']))
            shelf_life_dif = shelf_life_dif * float(zone_inf)
        
        if shelf_life_dif > 0:
            product['shelf_life'] = str(int(shelf_life_dif))
            
            shelf_dif = int(shelf_life_dif)
            year = int(t[0])
            month = int(t[1])
            if month == 12:
                month = 0
            day = int(t[2])
            days = int(months[month]) - int(t[2])
            first_days = int(months[month]) - int(t[2])
            i = 0
            while i != 1:
                if month == 12:
                    month = 0
                if month == 1 and first_days == -1:
                    year = year + 1
                if year % 4 == 0 and month == 2 and first_days == -1:
                    days = 29
                elif first_days == -1:
                    days = int(months[month])
                else:
                    days = first_days
                if shelf_dif > days:
                    shelf_dif = shelf_dif - days
                    month = month + 1
                    first_days = -1
                else:
                    if first_days != -1:
                        day = day + shelf_dif + 1
                    else:
                        day = first_days + shelf_dif + 2
                    if month == 2 and year % 4 == 0:
                        mon = 29
                    else:
                        mon = int(months[month])
                    if day > mon:
                        day = 1
                        month = month + 1
                    if month == 12:
                        month = 0
                    i = 1

            exp_date = [str(int(day)), months_names[month], str(year)]
            product['expiration_date'] = ' '.join(exp_date)
           
            
        elif shelf_life_dif <= 0:
            product['shelf_life'] = str(0)
            
            if int(product['expired']) == 0:
                expiration_day = datetime.now()
                product_spoiled(int(product['product_id']), expiration_day)
            product1 = get_product_inf(int(product['product_id']))
            exp_d = str(product1[0]['expiration_day']).split(' ')[0]
            if int(exp_d.split('-')[1]) == 12:
                exp_d.split('-')[1] = 0
            exp_date = str(int(exp_d.split('-')[2])) + ' ' + months_names[int(exp_d.split('-')[1])] + ' ' + str(exp_d.split('-')[0])
            product['expiration_date'] = exp_date
    return


@app.route("/get_scan_info", methods=["POST"])
def get_scan_info():
    from .tools import TrueSignParser
    import json

    data = json.loads(request.data)

    res = TrueSignParser.get_product(data["code"], "datamatrix" if data["dm"] else "ean-13")

    return json.dumps(res)


def send_nearly_exp_notification(nearly_exp_products, days_before_alert):
    if len(nearly_exp_products) > 3:
        body = "Через " + days_before_alert + "дней истечёт срок хранения у продуктов: " + nearly_exp_products[0] + ', ' + nearly_exp_products[1] + ', ' + nearly_exp_products[2] + ' и у ещё ' + (len(nearly_exp_products) - 3)
    elif len(nearly_exp_products) == 3:
        body = "Через " + days_before_alert + "дня истечёт срок хранения у продуктов: " + nearly_exp_products[0] + ', ' + nearly_exp_products[1] + ', ' + nearly_exp_products[2]
    elif len(nearly_exp_products) == 2:
        body = "Через " + days_before_alert + "дня истечёт срок хранения у продуктов: " + nearly_exp_products[0] + ', ' + nearly_exp_products[1]
    elif len(nearly_exp_products) == 1:
        body = "Через " + days_before_alert + "день истечёт срок хранения у продукта: " + nearly_exp_products[0]
    elif len(nearly_exp_products) == 0:
        body = "Через " + days_before_alert + "дн. ни у одного продукта не истекает срок хранения "
    return body

def send_exp_notification(exp_products):
    if len(exp_products) > 3:
        body = "Сегодня истёк срок хранения у продуктов: " + exp_products[0] + ', ' + exp_products[1] + ', ' + exp_products[2] + ' и у ещё ' + (len(exp_products) - 3)
    elif len(exp_products) == 3:
        body = "Сегодня истёк срок хранения у продуктов: " + exp_products[0] + ', ' + exp_products[1] + ', ' + exp_products[2]
    elif len(exp_products) == 2:
        body = "Сегодня истёк срок хранения у продуктов: " + exp_products[0] + ', ' + exp_products[1]
    elif len(exp_products) == 1:
        body = "Сегодня истёк срок хранения у продукта: " + exp_products[0]
    elif len(exp_products) == 0:
        body = "Сегодня ничего не просрочилось, так держать! "
    return body
