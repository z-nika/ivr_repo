

function matchDaysAndExpiryDate(sender) {
	var n_days = 0;
        if (sender.value.length > 0)
        	n_days = parseInt(sender.value);
        
	const prodDate = document.getElementsByName("production_date")[0].value;
	var newDate = new Date(prodDate);
        newDate.setDate(newDate.getDate() + n_days);

        var day = ("0" + newDate.getDate()).slice(-2);
        var month = ("0" + (newDate.getMonth() + 1)).slice(-2);
        var tgtDate = newDate.getFullYear() + "-" + (month)+"-"+(day);

	tgt_input = document.getElementsByName("expiration_date")[0];
        tgt_input.value = tgtDate;

}


