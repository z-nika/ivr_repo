from .fairsign import TrueSignParser
